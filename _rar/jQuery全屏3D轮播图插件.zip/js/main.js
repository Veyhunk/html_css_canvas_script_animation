'use strict';

$(document).ready(function() {
	
	$('.main-content').scroll3D();
	
});